package lecture_examples;

public class MyClassTester {

	public static void main(String[] args) {
		MyClass mc = new MyClass();

	}

}
