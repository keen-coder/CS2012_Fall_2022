package lecture_examples;

public class MyClass {
	private int x;

	
	
	public void myMethod() {
		System.out.println("hello world");
	}
}
